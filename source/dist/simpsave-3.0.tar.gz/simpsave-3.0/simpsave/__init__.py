from .simpsave import write, read, remove, match, delete, has

__all__ = ["write", "read", "remove", "match", "delete", "has"]
__version__ = "3.0"
__author__ = "WaterRun"
